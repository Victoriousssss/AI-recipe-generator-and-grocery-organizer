import sqlite3
from typing import List, Tuple, Optional

DB_NAME = "app_data.db"


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_NAME, check_same_thread=False)
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_db() -> None:
    conn = get_connection()
    cur = conn.cursor()
    # Grocery items table
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS grocery_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_name TEXT NOT NULL,
            quantity TEXT NOT NULL DEFAULT '1',
            purchased INTEGER NOT NULL DEFAULT 0
        );
        """
    )
    # Saved recipes table
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS saved_recipes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            recipe_name TEXT NOT NULL,
            ingredients TEXT NOT NULL,
            steps TEXT NOT NULL
        );
        """
    )
    conn.commit()
    conn.close()


# ----------------------
# Grocery CRUD
# ----------------------
def add_grocery_item(item_name: str, quantity: str = "1", purchased: bool = False) -> None:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO grocery_items (item_name, quantity, purchased) VALUES (?, ?, ?);",
        (item_name, quantity, 1 if purchased else 0),
    )
    conn.commit()
    conn.close()


def get_grocery_items() -> List[Tuple[int, str, str, int]]:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT id, item_name, quantity, purchased FROM grocery_items ORDER BY purchased ASC, id DESC;"
    )
    rows = cur.fetchall()
    conn.close()
    return rows


def update_grocery_item(item_id: int, item_name: str, quantity: str, purchased: bool) -> None:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        """
        UPDATE grocery_items
        SET item_name = ?, quantity = ?, purchased = ?
        WHERE id = ?;
        """,
        (item_name, quantity, 1 if purchased else 0, item_id),
    )
    conn.commit()
    conn.close()


def delete_grocery_item(item_id: int) -> None:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM grocery_items WHERE id = ?;", (item_id,))
    conn.commit()
    conn.close()


def clear_grocery_items() -> None:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM grocery_items;")
    conn.commit()
    conn.close()


# ----------------------
# Saved Recipes CRUD
# ----------------------
def add_saved_recipe(recipe_name: str, ingredients: str, steps: str) -> None:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO saved_recipes (recipe_name, ingredients, steps) VALUES (?, ?, ?);",
        (recipe_name, ingredients, steps),
    )
    conn.commit()
    conn.close()


def get_saved_recipes() -> List[Tuple[int, str, str, str]]:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT id, recipe_name, ingredients, steps FROM saved_recipes ORDER BY id DESC;"
    )
    rows = cur.fetchall()
    conn.close()
    return rows


def delete_saved_recipe(recipe_id: int) -> None:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM saved_recipes WHERE id = ?;", (recipe_id,))
    conn.commit()
    conn.close()


