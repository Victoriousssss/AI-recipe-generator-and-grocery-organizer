import os
import json
from typing import List, Dict, Any
from openai import OpenAI

# ----------------------
# System prompt for AI
# ----------------------
SYSTEM_PROMPT = (
    "You are a helpful culinary assistant. Always return EXACT JSON that matches the given schema. "
    "Do not include markdown or commentary."
)

# ----------------------
# Build prompt for user input
# ----------------------
def _build_user_prompt(user_ingredients: List[str], cuisine: str) -> str:
    ing_text = ", ".join(user_ingredients) if user_ingredients else ""
    return (
        "Suggest 3 recipes using the following ingredients in "
        f"{cuisine} style. Include recipe name, ingredients, and preparation steps.\n\n"
        "Return JSON with this exact schema: {\n"
        "  \"recipes\": [\n"
        "    { \"name\": string, \"ingredients\": [string], \"steps\": [string] },\n"
        "    { \"name\": string, \"ingredients\": [string], \"steps\": [string] },\n"
        "    { \"name\": string, \"ingredients\": [string], \"steps\": [string] }\n"
        "  ]\n"
        "}\n\n"
        f"User ingredients: {ing_text}"
    )

# ----------------------
# Parse AI response into recipe list
# ----------------------
def _parse_response_to_recipes(content: str) -> List[Dict[str, Any]]:
    try:
        data = json.loads(content)
        recipes = data.get("recipes", [])
        if isinstance(recipes, list):
            normalized: List[Dict[str, Any]] = []
            for r in recipes:
                name = r.get("name", "Untitled Recipe") if isinstance(r, dict) else str(r)
                ingredients = r.get("ingredients", []) if isinstance(r, dict) else []
                steps = r.get("steps", []) if isinstance(r, dict) else []

                # normalize types
                if not isinstance(ingredients, list):
                    ingredients = [str(ingredients)] if ingredients else []
                if not isinstance(steps, list):
                    steps = [str(steps)] if steps else []

                normalized.append({"name": name, "ingredients": ingredients, "steps": steps})
            return normalized
    except Exception:
        pass
    return []

# ----------------------
# Main function to generate recipes
# ----------------------
def generate_recipes_with_ai(user_ingredients: List[str], cuisine: str) -> List[Dict[str, Any]]:
    # Read API key from environment
    api_key = os.getenv("OPENAI_API_KEY")

    # Fallback recipes if API key missing or API fails
    fallback = [
        {
            "name": f"{cuisine} Inspired Stir-Fry",
            "ingredients": user_ingredients + ["salt", "pepper", "oil"],
            "steps": [
                "Prep and slice all ingredients.",
                "Heat oil in a pan and stir-fry ingredients.",
                "Season to taste and serve hot.",
            ],
        },
        {
            "name": f"{cuisine} One-Pot Rice",
            "ingredients": user_ingredients + ["rice", "spices", "water"],
            "steps": [
                "Rinse rice and combine with other ingredients in a pot.",
                "Simmer until rice is cooked.",
                "Fluff and serve.",
            ],
        },
        {
            "name": f"{cuisine} Quick Salad",
            "ingredients": user_ingredients + ["lemon", "olive oil"],
            "steps": [
                "Chop ingredients and toss in a bowl.",
                "Dress with lemon and olive oil.",
                "Adjust seasoning and serve.",
            ],
        },
    ]

    if not api_key:
        return fallback

    # Initialize OpenAI client
    client = OpenAI(api_key=api_key)
    prompt = _build_user_prompt(user_ingredients, cuisine)

    try:
        # Call OpenAI API
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            temperature=0.7,
            max_tokens=900,
        )
        content = response.choices[0].message.content or "{}"
        recipes = _parse_response_to_recipes(content)
        return recipes

    except Exception as e:
        # Gracefully fallback on any API error (quota, rate limit, network, etc.)
        print("OpenAI API failed, using fallback recipes.", e)
        return fallback
