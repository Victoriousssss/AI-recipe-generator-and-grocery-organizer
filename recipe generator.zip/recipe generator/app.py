import os
import json
from typing import List, Dict, Any

import streamlit as st

from database import (
    init_db,
    add_grocery_item,
    get_grocery_items,
    update_grocery_item,
    delete_grocery_item,
    clear_grocery_items,
    add_saved_recipe,
    get_saved_recipes,
    delete_saved_recipe,
)
from ai_utils import generate_recipes_with_ai


# ----------------------
# Helpers
# ----------------------
def ensure_session_state_defaults() -> None:
    if "generated_recipes" not in st.session_state:
        st.session_state.generated_recipes = []
    if "last_user_ingredients" not in st.session_state:
        st.session_state.last_user_ingredients = []


def normalize_ingredient_list(raw_text: str) -> List[str]:
    parts = [p.strip() for p in raw_text.split(",") if p.strip()]
    return [p.lower() for p in parts]


def compute_missing_ingredients(recipe_ingredients: List[str], user_ingredients: List[str]) -> List[str]:
    user_set = {i.lower() for i in user_ingredients}
    missing = []
    for ing in recipe_ingredients:
        normalized = ing.lower()
        if normalized not in user_set:
            missing.append(ing)
    return missing


def stringify_ingredients(ingredients: List[str]) -> str:
    return "\n".join(f"- {i}" for i in ingredients)


def stringify_steps(steps: List[str]) -> str:
    return "\n".join(f"{idx+1}. {s}" for idx, s in enumerate(steps))


# ----------------------
# UI Sections
# ----------------------
def render_generate_recipe_tab() -> None:
    st.subheader("Generate Recipe")
    ingredients_input = st.text_area(
        "Enter ingredients (comma-separated)",
        placeholder="e.g., tomato, onion, garlic, chicken, rice",
    )
    cuisine = st.selectbox(
        "Cuisine type",
        options=[
            "Indian",
            "Italian",
            "Chinese",
            "Mexican",
            "American",
            "Thai",
            "Japanese",
            "French",
            "Mediterranean",
            "Middle Eastern",
        ],
        index=0,
    )

    col_a, col_b = st.columns([1, 1])
    with col_a:
        generate_clicked = st.button("Generate Recipe", type="primary")
    with col_b:
        clear_clicked = st.button("Clear Results")

    if clear_clicked:
        st.session_state.generated_recipes = []

    if generate_clicked:
        user_ingredients = normalize_ingredient_list(ingredients_input) if ingredients_input else []
        st.session_state.last_user_ingredients = user_ingredients
        with st.spinner("Calling AI to generate recipes..."):
            recipes = generate_recipes_with_ai(user_ingredients, cuisine)
        st.session_state.generated_recipes = recipes

    if st.session_state.generated_recipes:
        st.markdown("---")
        st.subheader("Results")
        for idx, recipe in enumerate(st.session_state.generated_recipes):
            with st.expander(f"{idx+1}. {recipe.get('name', 'Untitled Recipe')}"):
                ingredients = recipe.get("ingredients", [])
                steps = recipe.get("steps", [])
                st.markdown("**Ingredients**")
                st.code(stringify_ingredients(ingredients))
                st.markdown("**Steps**")
                st.code(stringify_steps(steps))

                col1, col2 = st.columns([1, 1])
                with col1:
                    if st.button(
                        "Add missing ingredients to grocery list",
                        key=f"add_missing_{idx}",
                    ):
                        missing = compute_missing_ingredients(
                            ingredients, st.session_state.last_user_ingredients
                        )
                        added = 0
                        for item in missing:
                            add_grocery_item(item_name=item, quantity="1", purchased=False)
                            added += 1
                        if added:
                            st.success(f"Added {added} missing ingredient(s) to your grocery list.")
                        else:
                            st.info("No missing ingredients to add.")
                with col2:
                    if st.button("Save Recipe", key=f"save_recipe_{idx}"):
                        add_saved_recipe(
                            recipe_name=recipe.get("name", "Untitled"),
                            ingredients=json.dumps(ingredients, ensure_ascii=False),
                            steps=json.dumps(steps, ensure_ascii=False),
                        )
                        st.success("Recipe saved.")


def render_grocery_list_tab() -> None:
    st.subheader("My Grocery List")
    items = get_grocery_items()

    with st.form("add_item_form", clear_on_submit=True):
        st.markdown("**Add Item**")
        col1, col2, col3 = st.columns([3, 1, 1])
        with col1:
            new_name = st.text_input("Item name", key="add_name")
        with col2:
            new_qty = st.text_input("Qty", value="1", key="add_qty")
        with col3:
            submitted = st.form_submit_button("Add", type="primary")
        if submitted and new_name.strip():
            add_grocery_item(new_name.strip(), new_qty.strip() or "1", False)
            st.success("Item added.")

    st.markdown("---")

    if not items:
        st.info("Your grocery list is empty. Add your first item above.")
    else:
        for item in items:
            item_id = item[0]
            item_name = item[1]
            quantity = item[2]
            purchased = bool(item[3])

            container = st.container()
            cols = container.columns([0.1, 0.45, 0.2, 0.25])
            with cols[0]:
                new_purchased = st.checkbox("", value=purchased, key=f"p_{item_id}")
            with cols[1]:
                new_name_val = st.text_input("Name", value=item_name, key=f"n_{item_id}")
            with cols[2]:
                new_qty_val = st.text_input("Qty", value=quantity, key=f"q_{item_id}")
            with cols[3]:
                col_a, col_b = st.columns([1, 1])
                with col_a:
                    if st.button("Save", key=f"save_{item_id}"):
                        update_grocery_item(
                            item_id=item_id,
                            item_name=new_name_val.strip() or item_name,
                            quantity=new_qty_val.strip() or quantity,
                            purchased=new_purchased,
                        )
                        st.success("Updated.")
                with col_b:
                    if st.button("Delete", key=f"del_{item_id}"):
                        delete_grocery_item(item_id)
                        st.warning("Deleted.")

    st.markdown("---")
    col_left, col_right = st.columns([1, 1])
    with col_left:
        if st.button("Clear List"):
            clear_grocery_items()
            st.warning("Cleared grocery list.")
    with col_right:
        # Prepare export text
        items = get_grocery_items()
        export_lines = [
            f"[x] {name} x{qty}" if bool(p) else f"[ ] {name} x{qty}"
            for (_id, name, qty, p) in items
        ]
        export_text = "Grocery List\n\n" + "\n".join(export_lines)
        st.download_button(
            label="Export to .txt",
            data=export_text,
            file_name="grocery_list.txt",
            mime="text/plain",
        )


def render_saved_recipes_tab() -> None:
    st.subheader("Saved Recipes")
    recipes = get_saved_recipes()
    if not recipes:
        st.info("No saved recipes yet. Save from the Generate tab.")
        return

    for rec in recipes:
        rec_id = rec[0]
        name = rec[1]
        ingredients_json = rec[2]
        steps_json = rec[3]
        try:
            ingredients = json.loads(ingredients_json) if ingredients_json else []
        except Exception:
            ingredients = [str(ingredients_json)] if ingredients_json else []
        try:
            steps = json.loads(steps_json) if steps_json else []
        except Exception:
            steps = [str(steps_json)] if steps_json else []

        with st.expander(name):
            st.markdown("**Ingredients**")
            st.code(stringify_ingredients(ingredients))
            st.markdown("**Steps**")
            st.code(stringify_steps(steps))

            if st.button("Delete", key=f"delete_saved_{rec_id}"):
                delete_saved_recipe(rec_id)
                st.warning("Deleted recipe.")


def main() -> None:
    st.set_page_config(
        page_title="AI Recipe Generator & Grocery Organizer",
        page_icon="🍳",
        layout="centered",
        initial_sidebar_state="auto",
    )

    # Initialize database
    init_db()
    ensure_session_state_defaults()

    st.title("AI Recipe Generator & Grocery Organizer")
    st.caption("Generate recipes with AI, manage groceries, and save your favorites.")

    tabs = st.tabs(["Generate Recipe", "My Grocery List", "Saved Recipes"])
    with tabs[0]:
        render_generate_recipe_tab()
    with tabs[1]:
        render_grocery_list_tab()
    with tabs[2]:
        render_saved_recipes_tab()


if __name__ == "__main__":
    main()


